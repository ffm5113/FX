package model;

public interface ManageData {
    abstract void createAccount();
    abstract String hidePassword();
}
